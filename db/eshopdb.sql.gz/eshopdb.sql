-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Дек 30 2014 г., 14:09
-- Версия сервера: 5.5.25
-- Версия PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `eshopdb`
--

-- --------------------------------------------------------

--
-- Структура таблицы `catalog`
--

DROP TABLE IF EXISTS `catalog`;
CREATE TABLE IF NOT EXISTS `catalog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `model` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `charac` text CHARACTER SET utf8 COLLATE utf8_unicode_ci COMMENT 'characteristics',
  `description` text CHARACTER SET utf8 COLLATE utf8_unicode_ci COMMENT 'description',
  `phid` int(11) DEFAULT NULL COMMENT 'photo id',
  `price` int(11) DEFAULT NULL,
  `instock` int(11) NOT NULL COMMENT 'amount of items',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Дамп данных таблицы `catalog`
--

INSERT INTO `catalog` (`id`, `brand`, `model`, `charac`, `description`, `phid`, `price`, `instock`) VALUES
(1, 'Lenovo', 'S660', 'смартфон, Android 4.2\r\nподдержка двух SIM-карт\r\nэкран 4.7", разрешение 540x960\r\nкамера 8 МП, автофокус\r\nпамять 8 Гб, слот microSD (TransFlash)\r\nBluetooth, Wi-Fi, 3G, GPS\r\nаккумулятор 3000 мАч', 'Стильный Lenovo S660 предлагает все преимущества смартфона премиум-класса по приемлемой цене. Матовый металлический корпус и 4,7-дюймовый дисплей сочетаются с четырехъядерным процессором и аккумулятором высокой емкости, который обеспечит работу устройства на весь день. А благодаря фронтальной и задней камерам вы сможете легко делать и отправлять фотографии и общаться в видеочате.', NULL, 10500, 21),
(2, 'Nokia', 'Lumia 930', 'Экран 5" OLED (1920x1080, сенсорный) / моноблок / Snapdragon 800 (2.2 ГГц) / основная камера 20 Мп, фронтальная: 1.2 Мп / Bluetooth 4.0 / Wi-Fi 802.11 a/b/g/n/ac / RAM 2 ГБ / 32 ГБ встроенной памяти / разъем 3.5 мм / 3G / LTE / NFC / GPS / A-GPS / А-ГЛОНАСС / Windows Phone 8.1 / 137 x 71 x 9.8 мм, 167 г /', 'Смартфон Nokia Lumia 930 удобно лежит в кармане и в руке, вы можете выбрать его расцветку в диапазоне от изысканно скромной до дерзко модной. В смартфоне использованы многочисленные передовые технологии, включая процессор Snapdragon 800 с тактовой частотой 2.2 ГГц, поддержку сетей 4G (LTE), встроенную функцию беспроводной зарядки и 5-дюймовый дисплей стандарта Full HD, на котором все отлично видно даже при ярком солнечном освещении.', NULL, 24000, 14),
(3, 'HTC', 'Desire 616', 'Экран 5" (1280 x 720, сенсорный, Multi-Touch) / моноблок / Mediatek МТК 6592M (1.4 ГГц) / ОЗУ 1 ГБ / камера 8 Мп + фронтальная 2 Мп / Bluetooth 4.0 / Wi-Fi 802.11 b/g/n / 4 ГБ встроенной памяти + поддержка micro SD / поддержка 2-х СИМ-карт / разъем 3.5 мм / 3G / GPS / ОС Android 4.2 (Jelly Bean) / 142 x 71.9 x 9.15 мм, 150 г', 'Пятидюймовый Desire 616 с двумя SIM-картами, обеспечивающими гибкость работы, и восьмиядерным процессором, с легкостью справляющимся с несколькими задачами одновременно.\r\n', NULL, 14400, 10),
(4, 'HTC', 'Desire Eye', 'Экран 5.2" IPS (1920x1080), сенсорный, емкостный / моноблок / Qualcomm Snapdragon 801 (2.3 ГГц) / камера 13 Мп + фронтальная 13 Мп / Bluetooth 4.0 / Wi-Fi 802.11 a/b/g/n / RAM 2 ГБ / 16 ГБ встроенной памяти + поддержка microSD / разъем 3.5 мм / 3G / GPS / ГЛОНАСС / пылевлагозащищённый / ОС Android 4.4 (KitKat) / 151.7 x 73.8 x 8.5 мм, 154 г / синий', 'Снимайте потрясающие фотографии с двух сторон телефона: две камеры по 13 Мп спереди и сзади со встроенными инструментами для автопортретов, позволяющими редактировать изображения немедленно. Два фронтальных стереодинамика и 3 микрофона обеспечивают невероятный звук и чистоту голоса во время звонка. И все это в ярком двухцветном корпусе.', NULL, 29600, 8),
(6, 'Asus', 'ZenFone 5', 'Экран 5.0" IPS (1280x720, сенсорный, Multi-Touch) / моноблок / Intel Atom Z2560 (1.6 ГГц) / ОЗУ 2 ГБ / основная камера 8 Мп + фронтальная 2 Мп / Bluetooth 4.0 / Wi-Fi 802.11 b/g/n / 16 ГБ встроенной памяти + поддержка microSD / поддержка 2-х SIM-карт / разъем 3.5 мм / 3G / GPS / OC Android 4.3 (Jelly Bean) / 148.2 x 72.8 x 10.34 мм, 145 г /', 'ZenFone 5 — высокопроизводительный смартфон с широкой функциональностью, это удобное, современное и просто красивое устройство.', NULL, 16700, 9),
(7, 'Acer', 'Liquid Z500 DualSim', 'Экран 5" IPS (1280 x 720, сенсорный емкостный, Multi-Touch) / моноблок / Mediatek MT6582 (1.3 ГГц) / камера 8 Мп + фронтальная 2 Мп / Bluetooth 3.0 / Wi-Fi b/g/n / 1 ГБ оперативной памяти / 4 ГБ встроенной памяти + поддержка microSD / поддержка 2-х SIM-карт / разъем 3.5 мм / 3G / GPS / ОС Android 4.4.2 (KitKat) / 145.9 x 73 x 8.65 мм, 147 г', 'Смартфоны Acer серии Liquid Z — отличный выбор как для искушенных пользователей, так и для тех, кто впервые отказывается от обычного телефона в пользу смартфона. Эти устройства просты в использовании, имеют интуитивно понятный интерфейс и отличную производительность. Большой экран, расширенные возможности камеры и качественный звук позволят ежедневно наслаждаться мультимедийными возможностями смартфона.', NULL, 14300, 6),
(8, 'Fly', 'IQ4406 ERA Nano 6', 'Экран 4.5" (854 x 480) сенсорный / моноблок / MT6572AW (1.3 ГГц) / основная камера 5 Мп + фронтальная 0.3 Мп / Bluetooth / Wi-Fi / ОЗУ 512 МБ / 4 ГБ встроенной памяти + поддержка microSD / поддержка 2-х SIM-карт / разъем 3.5 мм / 3G / GPS / ОС Android 4.2.2 / 132.5 x 66.7 x 10.4 мм, 153 г', 'Fly IQ4406 ERA Nano 6 — стильный и очень мощный смартфон, удовлетворяющий всем требованиям современного пользователя мобильных устройств! Большой 4.5-дюймовый экран, двухъядерный процессор, ультратонкий корпус, новейшая версия Android 4.2 — когда вы возьмете устройство в руки, отдавать обратно его вам уже не захочется.', NULL, 6200, 12),
(9, 'Nokia', 'XL Dual Sim', 'Экран 5" IPS (800x480) сенсорный, Multi-Touch / моноблок / Qualcomm Snapdragon S4 (1 ГГц) / ОЗУ 768 МБ / основная камера 5 Мп, фронтальная 2 Мп / Bluetooth 3.0 / Wi-Fi 802.11 b/g/n / 4 ГБ встроенной памяти + поддержка microSD / поддержка 2-х СИМ-карт / разъем 3.5 мм / 3G / A-GPS / Android 4.1 (Jelly Bean) / 141.4 х 77.7 х 10.9 мм, 190 г', 'Nokia XL делает опыт пользования смартфоном ярче благодаря большому 5-дюймовому экрану и камере 5 Мпикс с автофокусом и вспышкой. А еще он красивый. Nokia XL ​​отмечается традиционной для Nokia надежной и прочной конструкцией.', NULL, 10200, 17),
(10, 'Lenovo', 'S820', 'Экран 4.7" (1280 x 720, сенсорный емкостный multi-touch) IPS Corning curved glass/ моноблок / четырехъядерный процессор MTK 6589W 1.2 ГГц / основная камера 12 Мп + фронтальная 2 Мп / Bluetooth 3.0 / Wi-Fi 802.11 a/b/g/n / 1 ГБ оперативной памяти / 8 ГБ встроенной памяти + поддержка microSD до 32 ГБ / поддержка 2-х СИМ-карт / разъем 3.5 мм / 3G / A-GPS / OC Android 4.2 / 139.5 x 69.7 x 8.95 мм, 143 г', 'С современным мощным четырехъядерным процессором Вам не придется терпеливо ожидать загрузки приложений или открытия файлов — все работает просто молниеносно, даже при просмотре HD-видео или тяжелых играх.', NULL, 8050, 13),
(11, 'Sony', 'Xperia V LT25i', 'Экран 4.3" (1280х720 сенсорный мультитач) / моноблок / 2-х ядерный процессор 1.5 ГГц / камера: основная 13 Мп, фронтальная VGA / Bluetooth / Wi-Fi 802.11a/b/g/n / NFC / MHL / 8 ГБ встроенной памяти + поддержка microSD / разъем 3.5 мм / 3G / aGPS, Glonass / ОС Android 4.0 / 129 x 65 x 10.7 мм, 120 г', 'Безукоризненное воспроизведение потокового видео. Быстрая загрузка и мгновенный запуск приложений. Благодаря невероятно быстрому двухъядерному процессору Qualcomm Snapdragon MSM8960 новейшего поколения с частотой 1.5 ГГц и высокой скорости работы LTE-смартфона навсегда можно забыть об ожидании.', NULL, 22100, 5);

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `oid` varchar(255) NOT NULL COMMENT 'orderid',
  `uid` int(11) DEFAULT NULL COMMENT 'userid',
  `iid` int(11) NOT NULL COMMENT 'item id',
  `brand` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `model` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=24 ;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `oid`, `uid`, `iid`, `brand`, `model`, `price`, `quantity`) VALUES
(19, '54a1e8fedaacc', NULL, 1, 'Lenovo', 'S660', 10500, 1),
(20, '54a1e8fedaacc', NULL, 3, 'HTC', 'Desire 616', 14400, 1),
(21, '54a1e8fedaacc', NULL, 6, 'Asus', 'ZenFone 5', 16700, 1),
(22, '54a1ea604af6b', NULL, 8, 'Fly', 'IQ4406 ERA Nano 6', 6200, 1),
(23, '54a1ea604af6b', NULL, 9, 'Nokia', 'XL Dual Sim', 10200, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `ordersinfo`
--

DROP TABLE IF EXISTS `ordersinfo`;
CREATE TABLE IF NOT EXISTS `ordersinfo` (
  `oid` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'order id',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `telephone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `ordersinfo`
--

INSERT INTO `ordersinfo` (`oid`, `name`, `email`, `telephone`, `address`, `date`) VALUES
('54a1e8fedaacc', 'Геннадий Адреев', 'gen123@yandex.ru', '3413424', 'г.Махачкала', '2014-12-29 23:57:20'),
('54a1ea604af6b', 'Дмитрий Рукопоп', 'fcfdfdfo@ya.ru', '86553442', 'г.Юта', '2014-12-29 23:57:42');

-- --------------------------------------------------------

--
-- Структура таблицы `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` int(11) NOT NULL,
  `phid` int(11) NOT NULL,
  `ref` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `reviews`
--

DROP TABLE IF EXISTS `reviews`;
CREATE TABLE IF NOT EXISTS `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `review` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `rate` int(11) DEFAULT NULL COMMENT '1-5',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `reviews`
--

INSERT INTO `reviews` (`id`, `name`, `email`, `review`, `rate`, `date`) VALUES
(2, 'Hank', 'hank187@mail.ru', 'смартфоны для гиков! Всем ТЕЛЕГРАФ!', 2, '2014-12-26 20:50:30'),
(3, 'Kidala', 'jemape@rambl.he', 'ich bin der atacen!', 3, '2014-12-26 20:51:41'),
(5, 'Pedal''ka', 'pedalka@mail.ru', 'Hate hate hate', 1, '2014-12-27 10:10:16'),
(6, 'O''henry', 'henry@gmail.com', 'You do it right!', 5, '2014-12-27 10:10:01');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `hash` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `salt` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `i` int(11) NOT NULL COMMENT 'iterations',
  `rights` varchar(6) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `hash`, `salt`, `i`, `rights`) VALUES
(5, 'Admin', '692f263cf34c19a3b3957c99b945a0e1fb82e62e', 'NzM1ZGI1MGVjYTU3MTQyNWRlNDU5ODA4MWViMjJhZTA', 12, 'admin'),
(6, 'Dydy', '97f8a60a3454df95a6a3406970d5b80cb47c5f5d', 'NTU1NTlmMmU1N2M3NDkzYmEyYTliNGU5MTRlNGNhZjY', 43, 'user');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
